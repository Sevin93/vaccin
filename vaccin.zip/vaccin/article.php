<?php
if (!isset($_GET['id']) || !is_numeric($_GET['id'])){
	header('Location:index.php');
}else {
    extract($_GET);
    $id = strip_tags($_GET['id']);
    require_once('model/comments.php');
    require_once('model/articles.php');
if (!empty($_POST)){
	$errors = array();

	$auteur = strip_tags($_POST['auteur']);
	$comment =  strip_tags($_POST['comment']);

	if (empty($auteur)){
		array_push($errors, 'Nom manquant');
	}

	if (empty($comment)){
		array_push($errors, 'Ecrire un commentaire');
	}

	if (count($errors) == 0){
		try{
			$comment = AddComment($id, $auteur, $comment);
			$success = "Votre commentaire est publié";
		} catch (Exception $e) {
			echo "probleme avec la methode Addcomment : ".$e->getMessage();
		}
		unset($comment);
		unset($auteur);
	}
}
   
   $article = GetArticle($id);
   $lescomments = GetComment($id);
}
?>

<!doctype html>
<html lang="fr">

<head>
     <meta charset="utf-8">
     <title>Tous les articles</title>
     <link rel="stylesheet" href="index.css">
<!--   <link rel="stylesheet" href="style.css">-->
<!--   <script src="script.js"></script>-->
</head>

<body>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
 
   <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
 <div class="page">
 	
<a class="waves-effect waves-light btn" href="index1.php">Retour</a>
<h1><?= $article->title ?></h1>
<time><?= $article->date ?></time>
<p><?= $article->contenu ?></p>

<?php
if (isset($success) && !empty($success)){
	echo $success;
}
if (!empty($errors)) {
	foreach ($errors as $error) {
		echo '<p>'.$error.'</p>';
	}
}

?>


<h2 class="titre card-panel pink">Commentaires</h2>
<?php

if(isset($lescomments) && !empty($lescomments)) {
    foreach($lescomments as $com){
        echo '<p>'.$com->auteur.' a écrit: </p>';
        echo '<p>'.$com->comment.'</p>';
        echo '<time>'.$com->date.'</time><br><hr>';

    }
}
?>


<h2 class="titre card-panel teal lighten-2">Laisser un commentaire</h2>
<form action="article.php?id=<?= $article->ID?>" method="post">
	<label for="auteur">Nom :</label><br>
	<input type="text" name="auteur" id="auteur" value="<?php if (isset($auteur)) echo $auteur?>"><br><br>

    <label for="comment"Commentaires :</label><br>
    <textarea name="comment" id="comment" cols="60" rows="10"><?php if (isset($comment)) echo $comment ?> </textarea><br><br>
   
    <button type="submit" class="waves-effect accent jaune-2 btn-large">Envoyer</button>

</div>
</body>
</html>