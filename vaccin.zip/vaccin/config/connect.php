<?php

function connect(){
   $database_name= "vaccin";
   $database_user= "root";
   $database_password= "";
   try{
       $bdd = new PDO('mysql:host=localhost;port=3306;dbname='.$database_name, $database_user, $database_password);
       return $bdd;
}   catch (PDOException $e) {
	echo 'Probleme connexion :'.$e->getMessage();
}
}
?>