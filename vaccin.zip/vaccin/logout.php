<?php
require_once('model/user.php');

$deconnect = logout();

if ($deconnect == 1 || $deconnect == 0) {
    echo "Vous êtes déconnecté\n";

    
    
} else {
    echo "Une erreur est survenue, veuillez nous en excuser, notre équipe va intervenir";
}
?>
<html>
   <head>
      <meta charset="utf-8">
   </head>
   <body>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
     
      <div class="center">
    <div class="col s12 m6">
      <div class="card teal violet foncé-4">
        <div class="card-content white-text">
          <span class="card-title">Vous avez déconnecté</span>
          <p>Vous voulez reconnecter?</p>
        </div>
        <div class="card-action">
          <a href="login.php">Connexion</a>
         
        </div>
      </div>
    </div>
  </div>
            

</body>
</html>
