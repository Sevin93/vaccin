<?php
require_once('model/user.php');

if (!empty($_POST)) {
    $errors = array();

    $email = strip_tags($_POST['email']);
    $motdepasse = strip_tags($_POST['motdepasse']);
    $pseudo = strip_tags($_POST['pseudo']);

    if (empty($email)) {
        array_push($errors, 'Email manquant');
    }

    if (empty($motdepasse)) {
        array_push($errors, 'Mot de passe manquant');
    }

    if (empty($pseudo)) {
        array_push($errors, 'Pseudo manquant');
    }

    if (count($errors) == 0){
        try {
            $user = addUser($email, $motdepasse, $pseudo);

            if ($user == false) {
                $return = "Le compte n'a pas pu être créé, veullez saisir un autre surname";
            }

        } catch (Exception $e) {
            echo "problème avec la méthode addUser : ".$e->getMessage();
        }

        unset($email);
        unset($motdepasse);
        unset($pseudo);
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>S'inscrire</title>
   <link rel="stylesheet" href="style.css">
<!--    <script src="script.js"></script>-->
</head>
<body>



<?php
if (isset($user) && $user == true) {
    header('Location:login.php');
} else {
    if (isset($return) && !empty($return)) {
        echo $return;
    }
}

if (!empty($errors)) {
    foreach ($errors as $error){
        echo '<p>'.$error.'</p>';
    }
}
?>

<form action="comUser.php" method="post">
    <div align="center">
    <h1>Créer votre compte</h1>
    <label for="email">Email :</label><br>
    <input type="text" name="email" id="email"><br><br>

    <label for="pseudo">Nom :</label><br>
    <input name="pseudo" id="pseudo"><br><br>

    <label for="motdepasse">Mot de passe :</label><br>
    <input type="password" name="motdepasse" id="motdepasse"><br><br>

    <button type="submit">Envoyer</button>
</div>
</form>

</body>
</html>