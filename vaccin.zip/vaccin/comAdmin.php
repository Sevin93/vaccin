<?php
require_once('model/user.php');
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 1) {
    //header('Location:../index.php');
}

if (!empty($_POST)) {
    $errors = array();
    $login= strip_tags($_POST['login']);
    $password = strip_tags($_POST['password']);
    $surname = strip_tags($_POST['surname']);

    if (empty($login)) {
        array_push($errors, 'Email manquant');
    }

    if (empty($password)) {
        array_push($errors, 'Mot de passe manquant');
    }
if (empty($surname)) {
        array_push($errors, 'Pseudo manquant');
    }

    if (count($errors) == 0){
        try {
            $admin = addAdmin($login, $password, $surname);
            $success = "Le compte a été créé";
            
        } catch (Exception $e) {
            echo "problème avec la méthode addAdmin : ".$e->getMessage();
        }
        unset($login);
        unset($password);
        unset($surname);
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Ajout admin</title>
     
     <link rel="stylesheet" href="style.css">

</head>
<body>
    


<div class="page">



<?php
if (isset($admin) && $admin == true) {
    header('Location:login1.php');
} else {
    if (isset($success) && !empty($success)) {
        echo $success;
    }
}

if (!empty($errors)) {
    foreach ($errors as $error){
        echo '<p>'.$error.'</p>';
    }
}
?>
 <div align="center">
    <h1>Inscription en tant qu'Admin</h1>
<form action="comAdmin.php?>" method="post">
    <label for="login">Email :</label><br>
    <input type="text" name="login" id="login"><br><br>

    <label for="surname">Nom:</label><br>
    <input name="surname" id="surname"><br><br>

    <label for="password">Mot de passe :</label><br>
    <input type="password" name="password" id="password"><br><br>

   <button type="submit">Envoyer</button>

</form>
</div>
</div>
</body>
</html>