<?php
session_start();
$_SESSION['session'] = session_id();
require_once('model/user.php');


?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Connexion</title>
</head>
<body>
    <link rel="stylesheet" href="index.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
    

<nav>
    <div class="nav-wrapper  teal lighten-2">
        
      <a href="index1.php" class="brand-logo">Acceuil</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="profil.php">Mon Profil</a></li>
        <li><a href="logout.php">Déconnexion</a></li>
        
    </div>
  </nav>
<div class="page">
<?php
if (isset($_SESSION['role']) && $_SESSION['role'] == 1) {
    echo '<h3>Bienvenue '.$_SESSION['nom'].'</h3>';
    echo '<a class="art" href="index.php">Ajouter de l\'article</a>';
    
}



if (isset($_SESSION['role']) && $_SESSION['role'] == 0) {
    echo '<h3>Bienvenue '.$_SESSION['nom'].'</h3>';
    
    
}

?>
</div>

<div class="row">
    <div class="col s100 m100">
      <div class="card-panel amber">
       
          <span class="card-title">Nos jours avec la vaccination du covid-19</span>
          <p>La vaccination contre la Covid-19 est ouverte en France pour les plus de 18 ans si des doses 
            restent disponibles en centre de vaccination. Elle est sinon prioritaire aux personnes âgées de 50 ans et plus et aux plus de 55 ans en médecine de ville et en pharmacie.
            La prise de rendez-vous est désormais possible pour les plus de 18 ans sans conditions (comorbidités...), si des doses sont encore disponibles dans les prochaines 24 heures et donc des rendez-vous encore libres. Il faut cependant être persévérant et consulter régulièrement les sites de prise de rendez-vous comme Doctolib ou Maiia au fil de la journée pour trouver des créneaux. Autre possibilité : aller sur Chronodose. Chronodose est une fonctionnalité du site Vite Ma Dose dédiée à la prise de rendez-vous pour les plus de 18 ans non prioritaires qui agrège les créneaux de Doctolib et Maiia disponibles autour de chez vous.</p>
        </div>
        
      </div>
    </div>
  </div>
  <div class="center">
    <div class="col s50 m50">
      <div class="card">
        <div class="card-image">
          <img src="vaccin_covid_adobestock.jpeg">
         
        </div>
        <div class="card-content">
          <p>Chaque jour de la semaine écoulée, 490.000 doses de vaccin anti-Covid ont été injectées en France. Cela signifie que 0,72% de la population française a reçu quotidiennement une dose.</p>
        </div>
        <div class="card-action">
          <a href="index1.php">Les vaccins de coronavirus</a>
        </div>
      </div>
    </div>
  </div>
</body>
</html>