<?php
session_start();
$_SESSION['session'] = session_id();
require_once('model/user.php');

if (!empty($_POST)) {
    $errors = array();

    $login = $_POST['login'];
    $password = $_POST['password'];
if (empty($login)) {
    array_push($errors, 'Login manquant');
}

if (empty($password)) {
    array_push($errors, 'Password manquant');
}
if (count($errors) == 0){
    try {
        $log = login($login, $password);
    } catch (Exception $e) {
        echo "problème avec la méthode addAdmin : ".$e->getMessage();
    }

    unset($login);
    unset($password);
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Connexion</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php
    if(isset($_SESSION['role']) && ($_SESSION['role']==0 || $_SESSION['role']==1 )){
        header('Location:login1.php');
    }
    else{
    
    echo '
    <div class="milieu" align="center">
        <h1 >Se connecter</h1>
        <form action="login.php" method="post">
            <label for="login">Nom :</label><br>
            <input type="text" name="login" id="login"><br><br>

            <label for="password">Mot de passe :</label><br>
            <input type="password" name="password" id="password"><br><br>

            <button type="submit">Envoyer</button>
    </div>
        </form>';}



?>

</body>
</html>