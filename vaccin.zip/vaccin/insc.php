
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Bienvenue</title>
 
   
</head>
<body>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
<hr>
  <div class="center">
    <div class="col s5 m5">
      <div class="card  blue">
        <div class="card-content white-text">
          <span class="card-title">Inscription </span>
          <p>Si vous êtes visiteur</p>
        </div>
            <div class="card-action">
          <a href="comUser.php">Inscrivez-vous</a>
        </div>
  <hr>
 <div class="center">
    <div class="col s5 m5">
      <div class="card white">
        <div class="card-content black-text">
          <span class="card-title">Inscription </span>
          <p>Si vous êtes administrateur</p>
        </div>
            <div class="card-action">
          <a href="comAdmin.php">Inscrivez-vous</a>
        </div>
  <hr>
 <div class="center">
    <div class="col s5 m5">
      <div class="card red">
        <div class="card-content white-text">
          <span class="card-title">Connexion </span>
          <p>Si vous avez déjà un compte</p>
        </div>
            <div class="card-action">
          <a href="login.php">Connectez-vous</a>
        </div>


</body>
</html>