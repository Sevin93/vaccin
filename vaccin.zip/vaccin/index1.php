<?php
require_once('model/articles.php');

   $lesarticles = getArticles();

?>

<!doctype html>
<html lang="fr">

<head>
     <meta charset="utf-8">
     <title>Vaccin</title>
     <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>

     
   <link rel="stylesheet" href="index.css">
<!--   <script src="script.js"></script>-->
</head>

<body>
  <nav>
    <div class="nav-wrapper  teal lighten-2">
        
      <a href="index1.php" class="brand-logo">Acceuil</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="login1.php">Home</a></li>
        <li><a href="profil.php">Mon Profil</a></li>
        <li><a href="logout.php">Déconnexion</a></li>
        
    </div>
  </nav>

  <div class="center">
     <h1>Les vaccins du Covid-19</h1>
   </div>

<div class="page">
<div class="row">
    <div class="col s6 m12">
      <div class="card-panel teal darken-3">
        

     <?php
          foreach ($lesarticles as $article) {
          echo '<h2>'.$article->title.'</h2>';
          echo '<time>'.$article->date.'</time><br>';
          echo '<a href="article.php?id='.$article->ID.'">Lire l\'article</a>';

          }
    ?>
    </div>
        <div class="row">
    <div class="col s6 m6">
      <div class="card">
        <div class="card-image">
          <img src="photo1" class="cen">
         
        </div>
        <div class="card-content">
          <a href="https://www.francebleu.fr/infos/sante-sciences/infographie-coronavirus-quand-pourrez-vous-vous-faire-vacciner-1614796923"><span class="card-title">Pour plus d'information appuyer ici</span></a>
        </div>
        
      </div>
    </div>
    <div class="col s6 m6">
      <div class="card">
        <div class="card-image">
          <img src="photo3" class="cen">
         
        </div>
        <div class="card-content">
          <a href="https://www.who.int/fr/news-room/q-a-detail/coronavirus-disease-covid-19"><span class="card-title">Pour plus d'information appuyer ici</span></a>
        </div>
        
      </div>
    </div>
      </div>
    </div>
  </div>
<?php
if (isset($success) && !empty($success)){
     echo $success;
}
if (!empty($errors)) {
     foreach ($errors as $error) {
          echo '<p>'.$error.'</p>';
     }
}

?>
</div>
</body>
</html>