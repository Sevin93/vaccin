<?php
require_once('config/connect.php');

function login($email, $motdepasse) {
    $hashpwd = hash('sha512', $motdepasse);

    $req = connect()->prepare("SELECT * FROM users WHERE pseudo = ? AND motdepasse= ?");
    $req->execute(array($email, $hashpwd));
    $user = $req->fetch(PDO::FETCH_OBJ);
    if ($user) {
        $_SESSION['id'] = $user->ID;
        $_SESSION['nom'] = $user->pseudo;
        $_SESSION['role'] = $user->role;
        $_SESSION['email'] = $user->email;
        $_SESSION['motdepasse'] = $user->motdepasse;
        $_SESSION['session'] = "";
        return $_SESSION;
    }

}
function addUser($email, $motdepasse, $pseudo) {
    try {

        $check = connect()->prepare("SELECT * FROM users WHERE pseudo = ?");
        $check->execute(array($pseudo));
        $result = $check->fetch(PDO::FETCH_OBJ);

        if ($result == false) {
            $hashpwd = hash('sha512', $motdepasse);
            $req = connect()->prepare("INSERT INTO users (email, motdepasse, pseudo, role, date) VALUES (?, ?, ?, 0, NOW())");
            $req->execute(array($email, $hashpwd, $pseudo));
            $req->closeCursor();
            return true;
        }else{
            return false;

        }

    }catch (PDOException $e) {
        echo "Le compte n'a pas été créé : ".$e->getMessage();
    }
  }
  //Fonction qui permet d'ajouter un utilisateur ADMIN
function addAdmin($login, $password,  $surname) {
    try {
        $hashpwd = hash('sha512', $password);
        $req = connect()->prepare("INSERT INTO users (email, motdepasse, pseudo, role, date) VALUES (?, ?, ?, 1, NOW())");
        $req->execute(array($login, $hashpwd, $surname));
        $req->closeCursor();
        return true;
    }catch (PDOException $e) {
        echo "Le compte ADMIN n'a pas été créé : ".$e->getMessage();
    }
    return false;
}
  function logout(){
  session_start();
  session_destroy();
  $_SESSION = array();

}

function GetUser($id){
 
  if(isset($_SESSION['id'])) {
   $getid = intval($_SESSION['id']);
   $requser= connect()->prepare('SELECT * FROM users WHERE id = ?');
   $requser->execute(array($getid));
   $userinfo = $requser->fetch();
   return $userinfo;
  }else{
    return null;
  }
}
function modifierUser( $pseudo, $motdepasse,$email){

    $req = connect()->prepare("UPDATE users SET pseudo=?, motdepasse=? WHERE email=?");
    $req->execute(array( $pseudo, $motdepasse,$email));
   $user = $req->fetch();
    
}
?>