<?php
require_once('config/connect.php');
function getArticles(){
	try{
        $req= connect()->prepare('SELECT ID, title, date FROM lesarticles ORDER BY ID DESC');
            $req->execute();
        $data = $req->fetchAll(PDO::FETCH_OBJ);
        return $data;
        $req->closeCursor();
	} catch (PDOException $a){
		echo 'Petit probleme : '.$e->getMessage();

	}
}
// fonction qui recupere un article selon l'id
function GetArticle($id){
  
	try{
       $req= connect()->prepare('SELECT * FROM lesarticles WHERE ID= ?');
       $req->execute(array($id));

       if ($req->rowCount() ==1){
           $data = $req->fetch(PDO::FETCH_OBJ);
           return $data;
       } else {
       	header('Location:index.php');
       }

        $req->closeCursor();
	} catch (PDOException $e){
		echo 'Petit probleme : '.$e->getMessage();

	}
}
function addarticle($title, $contenu){
  try{
       $req= connect()->prepare('INSERT INTO lesarticles (title, contenu, date) VALUES (?, ?, NOW())');
       $req->execute(array($title, $contenu));
       $req->closeCursor();
  } catch (PDOException $e){
    echo 'L\'article n\'as pas pu être enregistré : '.$e->getMessage();
  }
}

?>