<?php
require_once('config/connect.php');
function AddComment($articleid, $auteur, $comment){
  try{
       $req= connect()->prepare('INSERT INTO lescomments (articleid, auteur, comment, date) VALUES (?, ?, ?, NOW())');
       $req->execute(array($articleid, $auteur, $comment));
       $req->closeCursor();
  } catch (PDOException $e){
    echo 'Le commentaire n\'as pas pu être enregistré : '.$e->getMessage();
  }
}
//recuperer les commentaires
function GetComment($articleid){
  try{
       $req= connect()->prepare('SELECT * FROM lescomments WHERE articleid = ?');
       $req->execute(array($articleid));
       $data = $req->fetchALL(PDO::FETCH_OBJ);
           return $data;

      $req->closeCursor();
} catch (PDOException $e){
    echo 'Veuillez écrire un commentaire : '.$e->getMessage();
  }
}

?>