<?php
require_once('model/articles.php');


if (!empty($_POST)){
     $errors = array();

     $title = strip_tags($_POST['title']);
     $contenu =  strip_tags($_POST['contenu']);

     if (empty($title)){
          array_push($errors, 'TITRE MANQUANT');
     }

     if (empty($contenu)){
          array_push($errors, 'Ecrire un article');
     }


     if (count($errors) == 0){
          try{
               $article = addarticle($title, $contenu);
               $success = "Votre commentaire est publié";
          } catch (Exception $e) {
               echo "probleme avec la methode Addcomment : ".$e->getMessage();
          }
          unset($contenu);
      }    
     
}

   $lesarticles = getArticles();

?>

<!doctype html>
<html lang="fr">

<head>
     <meta charset="utf-8">
     <title>Vaccin</title>
     <title>Connexion</title>
    <link rel="stylesheet" href="index.css">
     <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>

     
<!--   <link rel="stylesheet" href="style.css">-->
<!--   <script src="script.js"></script>-->
</head>

<body>
     <nav>
    <div class="nav-wrapper  teal lighten-2">
        
      <a href="index1.php" class="brand-logo">Acceuil</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="login1.php">Home</a></li>
        <li><a href="profil.php">Mon Profil</a></li>
        <li><a href="logout.php">Déconnexion</a></li>
        
    </div>
  </nav>
     <h3>Les vaccins du Covid 19</h3>
<div class="page">

        

     <?php
          foreach ($lesarticles as $article) {
          echo '<h2>'.$article->title.'</h2>';
          echo '<time>'.$article->date.'</time><br>';
          echo '<a href="article.php?id='.$article->ID.'">Lire l\'article</a>';

          }
    ?>
<?php
if (isset($success) && !empty($success)){
     echo $success;
}
if (!empty($errors)) {
     foreach ($errors as $error) {
          echo '<p>'.$error.'</p>';
     }
}

?>

<form action="index.php" method="post">
    
 <label for="title">TITRE :</label><br>
     <input type="text" name="title" id="title" value="<?php if (isset($title)) echo $title?>"><br><br>
    <label for="contenu"VACCIN :</label><br>
    <textarea name="contenu" id="contenu" cols="60" rows="10"><?php if (isset($contenu)) echo $contenu ?> </textarea> <br><br>
    <button type="submit">Publier</button>
    
</form>
</div>
</body>
</html>