<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 1) {
   //header('Location:../index.php');
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Admin</title>
</head>
<body>
    <h1>Bienvenue <?= $_SESSION['nom']?></h1>

    <h2>Accueil des admins</h2>

    <a href="comAdmin.php">Inscription en tant qu'Admin</a><br>
    <a href="../logout.php">Se deconnecter</a>
    <a href="../profil.php">mon profil</a>

</body>
</html>