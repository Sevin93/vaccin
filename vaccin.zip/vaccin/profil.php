<?php
session_start();
require_once('model/user.php');
$id=$_SESSION['id'];
$profil = GetUser($id);
if (!empty($_POST)) {
    $errors = array();

    $email = $_SESSION['email'];
    $pseudo = $_POST['pseudo'];
    $motdepasse = $_POST['motdepasse'];

if (empty($pseudo)) {
    array_push($errors, 'pseudo manquant');
}
if (empty($motdepasse)) {
    array_push($errors, 'Password manquant');
}
if (count($errors) == 0){
    try {
        modifierUser($pseudo, $motdepasse,$email);
    } catch (Exception $e) {
        echo "problème avec la méthode addAdmin : ".$e->getMessage();
    }

    unset($login);
    unset($password);
    }
}


?>
<html>
   <head>
      <title>Mon profil</title>
      <meta charset="utf-8">
   </head>
   <body>
    <link rel="stylesheet" href="index.css">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
      <nav>
    <div class="nav-wrapper  teal lighten-2">
        
      <a href="index1.php" class="brand-logo">Acceuil</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        
        <li><a href="login1.php">Home</a></li>
        <li><a href="logout.php">Déconnexion</a></li>
      
    </div>
  </nav>

<?php


if (!empty($errors)) {
  foreach ($errors as $error) {
    echo '<p>'.$error.'</p>';
  }
}

?>
    <div class="page">
    
<form action="profil.php" method="post">
    <div align="center">
    <h3>Votre Compte</h3>
    <label for="email">Email :</label><br>
    <input type="text" name="email" value="<?= $_SESSION['email']?>"><br><br>

    <label for="pseudo">Nom :</label><br>
    <input type="text" name="pseudo" value="<?= $_SESSION['nom']?>"><br><br>

    <label for="motdepasse">Mot de passe :</label><br>
    <input type="password" name="motdepasse" value=""><br><br>


    <button type="submit" class="waves-effect accent jaune-2 btn-large">Modifier</button>
    </div>
</div>
</form>
        
         
     
   </body>
</html>